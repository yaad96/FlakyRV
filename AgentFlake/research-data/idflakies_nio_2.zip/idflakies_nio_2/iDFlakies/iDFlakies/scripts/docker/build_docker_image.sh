#!/bin/bash

sudo docker build -t $1 - < $2_Dockerfile
