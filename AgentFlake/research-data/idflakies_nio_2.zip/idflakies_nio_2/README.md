To run the same test twice in the same JVM to detect Non-Idempotent-Outcome (NIO) flaky test:

1) Change testrunner version to 1.4-SNAPSHOT in root pom.xml file
2) Change iDFlakies version to 1.2.0-SNAPSHOT in root pom.xml file
3) Run ```idflakies-pom-modify/modify-project.sh . "1.2.0-SNAPSHOT" "1.4-SNAPSHOT"``` in the project's root directory (this will add testrunner and iDFlakies in the project's POM files) 
4) run ```mkdir -p "<module_name>/.dtfixingtools" 
echo "<test_name>" > "<module_name>/.dtfixingtools/original-order"``` (use the test name and module name the test belongs to)
5) run ```timeout 2h mvn testrunner:testplugin  -pl "<module-name>" -Ddependency-check.skip=true -Dgpg.skip=true -DfailIfNoTests=false -Dskip.installnodenpm -Dskip.npm -Dskip.yarn -Dlicense.skip -Dcheckstyle.skip -Drat.skip -Denforcer.skip -Danimal.sniffer.skip -Dmaven.javadoc.skip -Dfindbugs.skip -Dwarbucks.skip -Dmodernizer.skip -Dimpsort.skip -Dmdep.analyze.skip -Dpgpverify.skip -Dxml.skip -Dcobertura.skip=true -Dfindbugs.skip=true -Ddt.detector.original_order.all_must_pass=false -Ddt.randomize.rounds=0 -Ddt.detector.original_order.retry_count=1 -Dtestplugin.runner.idempotent.num.runs=2 -Dtestplugin.runner.consec.idempotent=true -Ddt.detector.forceJUnit4=true -Ddetector.detector_type=original```
(this will run the suspected NIO test twice in the same JVM)
6) Look into the `.dtfixingtools/test-runs/results folder` and find a json file which can be viewed using ```cat <file_name> | python3 -m json.tool```. If the first run result is 'PASS' and second run result is 'FAIL/FAILURE/ERROR' - then it is a NIO test.
